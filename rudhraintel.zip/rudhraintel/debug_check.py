from vector_store.chroma_client import get_collection
collection=get_collection()
print("vector count",collection.count())