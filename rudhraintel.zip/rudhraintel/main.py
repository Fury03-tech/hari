from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

# Vector store imports
from vector_store.retrieve import retrieve_chunks

app = FastAPI(title="Rudhraintel")
@app.get("/")
def health_check():
    return {"status": "Rudhraintel backend is running"}

class QueryRequest(BaseModel):
    query_embedding: List[float]
    user_role: str
    top_k: int = 5

@app.post("/query")
def query_documents(request: QueryRequest):
    results = retrieve_chunks(
        query_embedding=request.query_embedding,
        user_role=request.user_role,
        top_k=request.top_k
    )

    return {
        "chunks": results["chunks"],
        "scores": results["scores"],
        "metadata": results["metadatas"]
    }
